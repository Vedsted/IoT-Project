create table `Groups`
(
    id            varchar(255) not null,
    controller_id varchar(255) not null,
    primary key (id, controller_id),
    constraint Groups_Controllers_id_fk
        foreign key (controller_id) references Controllers (id)
            on update cascade on delete cascade
);

INSERT INTO FilipsBlue.`Groups` (id, controller_id) VALUES ('cc1', 'controller1');
INSERT INTO FilipsBlue.`Groups` (id, controller_id) VALUES ('cc2', 'controller1');
INSERT INTO FilipsBlue.`Groups` (id, controller_id) VALUES ('cc3', 'controller1');
INSERT INTO FilipsBlue.`Groups` (id, controller_id) VALUES ('cc4', 'controller1');
INSERT INTO FilipsBlue.`Groups` (id, controller_id) VALUES ('group1', 'controller1');
INSERT INTO FilipsBlue.`Groups` (id, controller_id) VALUES ('group1', 'controller2');
INSERT INTO FilipsBlue.`Groups` (id, controller_id) VALUES ('group_vedsted', 'controller_vedsted');
INSERT INTO FilipsBlue.`Groups` (id, controller_id) VALUES ('jonso16', 'jonso16');
INSERT INTO FilipsBlue.`Groups` (id, controller_id) VALUES ('jv', 'jv');