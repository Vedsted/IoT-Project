create table Controllers
(
    id varchar(255) not null
        primary key
);

INSERT INTO FilipsBlue.Controllers (id) VALUES ('controller1');
INSERT INTO FilipsBlue.Controllers (id) VALUES ('controller2');
INSERT INTO FilipsBlue.Controllers (id) VALUES ('controller_vedsted');
INSERT INTO FilipsBlue.Controllers (id) VALUES ('jonso16');
INSERT INTO FilipsBlue.Controllers (id) VALUES ('jv');